﻿CREATE TABLE Matches (
    MatchId INT AUTO_INCREMENT PRIMARY KEY,
    UserId1 INT NOT NULL,
    UserId2 INT NOT NULL,
    MatchedAt TIMESTAMP,
    IsAccepted BOOLEAN,
    FOREIGN KEY (UserId1) REFERENCES Users(Id),
    FOREIGN KEY (UserId2) REFERENCES Users(Id)
);